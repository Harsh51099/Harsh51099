<?php
$city = 'london';
$api_key = 'ac16906d1f0904cac53cd65e86d040f2';
$url = 'http://api.openweathermap.org/data/2.5/weather?q='. $city. '&appid='. $api_key;

$weather_data = json_decode(file_get_contents($url), true);

echo "<pre>";
print_r($weather_data);
?>